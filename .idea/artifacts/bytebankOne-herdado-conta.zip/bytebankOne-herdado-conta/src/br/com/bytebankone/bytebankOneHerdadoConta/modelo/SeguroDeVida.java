package br.com.bytebankone.bytebankOneHerdadoConta.modelo;

public class SeguroDeVida implements Tributavel {
    public SeguroDeVida() {
    }

    public double getValorImposto() {
        return 42.0D;
    }
}
