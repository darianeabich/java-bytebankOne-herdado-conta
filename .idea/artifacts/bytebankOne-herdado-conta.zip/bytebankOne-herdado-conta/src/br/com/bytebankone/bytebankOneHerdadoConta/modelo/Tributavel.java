package br.com.bytebankone.bytebankOneHerdadoConta.modelo;

public interface Tributavel {
    double getValorImposto();
}
